/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 23, 2016, 9:41 AM
 * Purpose: Use switch case to determine grade
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int grade;
    
    cout << "What is the grade? Round down, to the nearest multiple of 10." << endl;
    cin >> grade;
    
    switch (grade)
    {
        case 100: cout << "You got an A." << endl; break;
        case 90: cout << "You got an A." << endl; break;
        case 80: cout << "You got a B." << endl; break;
        case 70: cout << "You got a C." << endl; break;
        case 60: cout << "You got a D." << endl; break;
        case 50: cout << "You got an F." << endl; break;
        case 40: cout << "You got an F." << endl; break;
        case 30: cout << "You got an F." << endl; break;
        case 20: cout << "You got an F." << endl; break;
        case 10: cout << "You got an F." << endl; break;
        case 0: cout << "You got an F." << endl; break;
        default: cout << "Please enter a grade 0 or above, rounding down to the nearest multiple of 10." << endl;
    }
    
    return 0;
}