/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 23, 2016, 9:41 AM
 * Purpose: Use independent if to determine grade
 */

#include <iostream>

using namespace std;

int main() 
{
    //declare variables
    int grade;
    
    cout << "What is the grade? Enter as an integer." << endl;
    cin >> grade;
    
    if (grade >= 90)
        cout << grade << " is an A" << endl;
    if (90 > grade && grade >= 80)
        cout << grade << " is a B" << endl;
    if (80 > grade && grade >= 70)
        cout << grade << " is a C" << endl;
    if (70 > grade && grade >= 60)
        cout << grade << " is a D" << endl;
    if (60 > grade && grade >= 0)
        cout << grade << " is an F" << endl;
    if (grade < 0)
        cout << "Please input a grade above 0." << endl;
    
    return 0;
}